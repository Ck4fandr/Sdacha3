<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>«Самоход»</title>

        <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">
        <link rel="stylesheet" href="{{ asset('css/main.css') }}">
    </head>
    <body>
        <section id="app" class="container py-3">
            <header-component></header-component>
            <router-view></router-view>
            <footer-component></footer-component>
        </section>
    </body>
    <script type="module" src="{{ asset('js/src/vue.js')  }}"></script>
    <script type="module" src="{{ asset('js/src/vue-router.js')  }}"></script>
    <script type="module">
        import Header from './js/components/Header.js';
        import Footer from './js/components/Footer.js';
        import Main from './js/components/Main.js';
        import About from './js/components/About.js';
        import Map from './js/components/Map.js';

        const routes = [
            {
                path: '/',
                component: Main,
            },
            {
                path: '/about',
                component: About,
            },
            {
                path: '/map',
                component: Map,
            },
        ];

        new Vue({
            el: '#app',
            data(){
                return {

                }
            },
            router: new VueRouter({
                mode: 'history',
                routes,
            }),
            components: {
                'header-component': Header,
                'footer-component': Footer,
            }
        });
    </script>
</html>
