export default{
    data(){
        return {
            isUser: false,
        }
    },

    template: `<header>
    <div class="d-flex flex-column flex-md-row align-items-center pb-3 mb-4 border-bottom">
        <router-link to="/" class="d-flex align-items-center text-dark text-decoration-none">
            <span class="fs-4">Мир цветов</span>
        </router-link>

        <nav class="d-inline-flex mt-2 mt-md-0 ms-md-auto">
            <router-link  class="me-3 py-2 text-dark text-decoration-none" to="/about" >О нас</router-link>
            <router-link  class="me-3 py-2 text-dark text-decoration-none" to="/map">Где нас найти ?</router-link>
            <router-link  class="me-3 py-2 text-dark text-decoration-none" to="/cart">Вход</router-link>
            <a v-if="isUser" @click.prevent="logout()" class="me-3 py-2 text-dark text-decoration-none" style="cursor:pointer">Выход</a>
        </nav>
    </div>
</header>`
}