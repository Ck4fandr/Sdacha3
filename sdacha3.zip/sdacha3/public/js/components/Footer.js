export default {
    data(){
        return {

        }
    },
    template: `<footer>
    
</footer>`
}