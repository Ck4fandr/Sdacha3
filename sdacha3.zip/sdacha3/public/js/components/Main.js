export default {
    data(){
        return {
            
        }
    },

    template: `<main>
    <h1 class="h1">Каталог</a>
</main>`
}