export default {
    data(){
        return {
            
        }
    },

    template: `<main>
    <h1 class="h1">About</a>
</main>`
}